﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace loop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sum = 0;
            for (int i = 0; i < 5; i++)
            {
                sum = sum + i;
                for (int j = 0; j < 5; j++)
                {
                    sum = sum + j;
                }
            }

            MessageBox.Show("res is: "+sum);
        }
    }
}
